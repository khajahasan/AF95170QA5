module.exports = {
    channel_form_bootstrap: "com.hcl.voltmx.formBootstrap",

    channel_form_maximized: "com.hcl.voltmx.form.maximized",
    channel_form_minimized: "com.hcl.voltmx.form.minimized",
    channel_form_restored: "com.hcl.voltmx.form.restored",
    channel_form_resized: "com.hcl.voltmx.form.resized",

    channel_form_enableMaximizable: "com.hcl.voltmx.form.enableMaximizable",
    channel_form_enableMinimizable: "com.hcl.voltmx.form.enableMinimizable",
    channel_form_enableRestorable: "com.hcl.voltmx.form.enableRestorable",
    channel_form_enableClosable: "com.hcl.voltmx.form.enableClosable",

    channel_form_setTitle: "com.hcl.voltmx.form.setTitle"

}