const IPC_Events = {
    OPEN_DATABASE: 'open_database',
    OPEN_DATABASE_WITH_ENCRYPTION: 'open_database_with_encryption',
    EXECUTE_SELECT_QUERY: 'execute_select_query',
    EXECUTE_SELECT_PREPARED_STATEMENTS: 'execute_select_prepared_statements',
    EXECUTE_RAW_QUERY: 'execute_raw_query',
    EXECUTE_QUERIES: 'execute_queries',
    EXECUTE_PREPARED_STATEMENTS: 'execute_prepared_statements',
    EXECUTE_PREPARED_STATEMENT: 'execute_prepared_statement',
    EXECUTE_SINGLE_INSERT_STATEMENT: 'execute_single_insert_statement'
};

module.exports = IPC_Events;