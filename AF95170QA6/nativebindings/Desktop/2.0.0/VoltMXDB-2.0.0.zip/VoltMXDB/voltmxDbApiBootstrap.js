module.exports = {
    channel_db_bootstrap: "com.hcl.voltmx.dbBootstrap",

    channel_db_changeVersion: "com.hcl.voltmx.changeVersion",
    channel_db_executeSql: "com.hcl.voltmx.executeSql",
    channel_db_openDatabase: "com.hcl.voltmx.openDatabase",
    channel_db_closeDatabase: "com.hcl.voltmx.closeDatabase",
    channel_db_sqlResultsetRowItem: "com.hcl.voltmx.sqlResultsetRowItem",
    channel_db_readTransaction: "com.hcl.voltmx.readTransaction",
    channel_db_begin_transaction: "com.hcl.voltmx.beginTransaction",
    channel_db_commit_transaction: "com.hcl.voltmx.commitTransaction",
    channel_db_rollback_transaction: "com.hcl.voltmx.rollbackTransaction"

}